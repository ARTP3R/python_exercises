#!/usr/bin/python3


def sumar(op1, op2):
	print("Suma es ", op1+op2)

def restar(op1, op2):
	print("Resta es ", op1-op2)

def multiplicar(op1, op2):
	print("Multiplicación es" , op1*op2)

def dividir(dividendo, divisor):
	print("División es ", dividendo/divisor)

def potencia(base, exponente):
	print("Potencia es ", base**exponente)

def redondear(numero):
	print("Redondeo es ", round(numero))