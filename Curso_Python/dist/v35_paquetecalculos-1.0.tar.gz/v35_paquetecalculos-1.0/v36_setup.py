#!/usr/bin/python3

from setuptools import setup

setup(

	name="v35_paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Arturo",
	author_email="",
	url="perezestudio.com",
	packages=["v35_calculos","v35_calculos.v35_redondeo_potencia"]

	)