#!/usr/bin/python3

def potencia(base, exponente):
	print("Potencia es ", base**exponente)

def redondear(numero):
	print("Redondeo es ", round(numero))